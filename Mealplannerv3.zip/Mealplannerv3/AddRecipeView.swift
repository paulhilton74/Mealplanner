import SwiftUI
import PhotosUI
import CoreData

struct AddRecipeView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.managedObjectContext) private var viewContext
    @StateObject private var recipeManager = RecipeManager.shared

    enum InputMode {
        case url, image, manual
    }

    @State private var selectedMode: InputMode? = nil
    @State private var title = ""
    @State private var ingredients = [""]
    @State private var instructions = [""]
    @State private var tags = [""]
    @State private var sourceURL = ""
    @State private var selectedItem: PhotosPickerItem?
    @State private var selectedImageData: Data?
    @State private var isExtracting = false

    var body: some View {
        NavigationView {
            Group {
                if let mode = selectedMode {
                    recipeFormView(for: mode)
                } else {
                    inputSelectionView
                }
            }
            .navigationTitle("Add Recipe")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                if selectedMode != nil {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button("Save") {
                            saveRecipe()
                        }
                        .disabled(title.isEmpty ||
                                  ingredients.allSatisfy { $0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty } ||
                                  instructions.allSatisfy { $0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty })
                    }
                }
            }
        }
    }

    private var inputSelectionView: some View {
        VStack(spacing: 20) {
            Text("Choose Input Method")
                .font(.title2)
                .bold()
                .padding(.top, 30)

            VStack(spacing: 16) {
                inputOptionButton(title: "Add from Recipe URL", icon: "link", mode: .url)
                inputOptionButton(title: "Add Recipe from Image", icon: "photo", mode: .image)
                inputOptionButton(title: "Enter Recipe Manually", icon: "square.and.pencil", mode: .manual)
            }
            .padding()

            Spacer()
        }
    }

    private func inputOptionButton(title: String, icon: String, mode: InputMode) -> some View {
        Button(action: { selectedMode = mode }) {
            HStack {
                Image(systemName: icon)
                    .font(.title2)
                    .frame(width: 30)
                Text(title)
                    .font(.headline)
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundColor(.gray)
            }
            .padding()
            .background(Color(.systemBackground))
            .cornerRadius(10)
        }
    }

    @ViewBuilder
    private func recipeFormView(for mode: InputMode) -> some View {
        Form {
            if mode == .url {
                Section(header: Text("Recipe URL")) {
                    TextField("Enter recipe URL", text: $sourceURL)
                    Button(action: extractRecipe) {
                        HStack {
                            Text("Extract Recipe")
                            if isExtracting {
                                Spacer()
                                ProgressView()
                            }
                        }
                    }
                    .disabled(sourceURL.isEmpty || isExtracting)
                }
            }

            Section(header: Text("Recipe Details")) {
                TextField("Recipe Title", text: $title)

                if mode == .image {
                    PhotosPicker(selection: $selectedItem, matching: .images) {
                        if let selectedImageData,
                           let uiImage = UIImage(data: selectedImageData) {
                            Image(uiImage: uiImage)
                                .resizable()
                                .scaledToFit()
                                .frame(height: 200)
                        } else {
                            Label("Select Image", systemImage: "photo")
                        }
                    }
                    .onChange(of: selectedItem) { _, newValue in
                        Task {
                            if let data = try? await newValue?.loadTransferable(type: Data.self) {
                                selectedImageData = data
                            }
                        }
                    }
                }
            }

            Section(header: Text("Ingredients")) {
                ForEach(ingredients.indices, id: \.self) { index in
                    HStack {
                        TextField("Ingredient \(index + 1)", text: $ingredients[index])
                        if ingredients.count > 1 {
                            Button(action: { ingredients.remove(at: index) }) {
                                Image(systemName: "minus.circle.fill")
                                    .foregroundColor(.red)
                            }
                        }
                    }
                }
                Button("Add Ingredient") {
                    ingredients.append("")
                }
            }

            Section(header: Text("Instructions")) {
                ForEach(instructions.indices, id: \.self) { index in
                    HStack {
                        TextField("Step \(index + 1)", text: $instructions[index])
                        if instructions.count > 1 {
                            Button(action: { instructions.remove(at: index) }) {
                                Image(systemName: "minus.circle.fill")
                                    .foregroundColor(.red)
                            }
                        }
                    }
                }
                Button("Add Step") {
                    instructions.append("")
                }
            }

            Section(header: Text("Tags")) {
                ForEach(tags.indices, id: \.self) { index in
                    HStack {
                        TextField("Tag \(index + 1)", text: $tags[index])
                        if tags.count > 1 {
                            Button(action: { tags.remove(at: index) }) {
                                Image(systemName: "minus.circle.fill")
                                    .foregroundColor(.red)
                            }
                        }
                    }
                }
                Button("Add Tag") {
                    tags.append("")
                }
            }
        }
    }

    private func extractRecipe() {
        isExtracting = true

        guard let url = URL(string: sourceURL) else {
            isExtracting = false
            print("Invalid URL format")
            return
        }

        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                defer { self.isExtracting = false }

                if let error = error {
                    print("Error fetching recipe: \(error)")
                    return
                }

                guard let data = data,
                      let html = String(data: data, encoding: .utf8) else {
                    print("Error decoding data")
                    return
                }

                if let recipeData = self.extractRecipeData(from: html) {
                    self.title = recipeData.title

                    if !recipeData.ingredients.isEmpty {
                        self.ingredients = recipeData.ingredients
                    } else {
                        print("No ingredients extracted.")
                    }

                    if !recipeData.instructions.isEmpty {
                        self.instructions = recipeData.instructions
                    } else {
                        print("No instructions extracted.")
                    }

                    if let imageURLString = recipeData.images.first,
                       let imageURL = URL(string: imageURLString) {
                        self.downloadImage(from: imageURL)
                    }
                } else {
                    print("Failed to extract recipe data")
                }
            }
        }
        task.resume()
    }

    private func extractRecipeData(from html: String) -> (title: String, ingredients: [String], instructions: [String], images: [String])? {
        // 1) Try JSON-LD first
        if let jsonLDData = extractJSONLD(from: html) {
            return jsonLDData
        }
        
        // 2) Try Microdata
        if let microdataResult = extractMicrodata(from: html) {
            return microdataResult
        }
        
        // 3) Use the new RecipeExtractorService
        let extractorService = RecipeExtractorService(apiKey: "")
        
        // Create a temporary URL for the extractor
        let url = URL(string: sourceURL) ?? URL(string: "https://example.com")!
        
        // Use a synchronous approach to extract recipe data
        var extractedRecipe: Recipe?
        let semaphore = DispatchSemaphore(value: 0)
        
        Task {
            do {
                extractedRecipe = try await extractorService.extractRecipe(from: sourceURL)
                semaphore.signal()
            } catch {
                print("Recipe extraction error: \(error)")
                semaphore.signal()
            }
        }
        
        // Wait for the extraction to complete
        _ = semaphore.wait(timeout: .now() + 5)
        
        // If extraction was successful, return the recipe data
        if let recipe = extractedRecipe {
            return (
                title: recipe.title,
                ingredients: recipe.ingredients,
                instructions: recipe.instructions,
                images: recipe.images
            )
        }
        
        return nil
    }

    private func extractJSONLD(from html: String) -> (title: String, ingredients: [String], instructions: [String], images: [String])? {
        let pattern = "<script[^>]*type=\"application/ld\\+json\"[^>]*>\\s*(.+?)\\s*</script>"
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.dotMatchesLineSeparators]),
              let match = regex.firstMatch(in: html, range: NSRange(html.startIndex..., in: html)),
              let dataRange = Range(match.range(at: 1), in: html) else {
            return nil
        }

        let jsonString = String(html[dataRange])
        guard let jsonData = jsonString.data(using: .utf8),
              let json = try? JSONSerialization.jsonObject(with: jsonData) as? [String: Any] else {
            return nil
        }

        // Find recipe data
        let recipeData: [String: Any]
        if let type = json["@type"] as? String, type == "Recipe" {
            recipeData = json
        } else if let graph = json["@graph"] as? [[String: Any]],
                  let recipe = graph.first(where: { ($0["@type"] as? String) == "Recipe" }) {
            recipeData = recipe
        } else {
            return nil
        }

        // Extract title
        guard let title = recipeData["name"] as? String else { return nil }

        // Extract ingredients with fallback for single-string ingredients.
        var ingredients: [String] = []
        if let ingredientList = recipeData["recipeIngredient"] as? [String] {
            ingredients = ingredientList
        } else if let ingredientList = recipeData["ingredients"] as? [String] {
            ingredients = ingredientList
        } else if let ingredientString = recipeData["recipeIngredient"] as? String {
            ingredients = ingredientString.components(separatedBy: "\n")
                .filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        } else if let ingredientString = recipeData["ingredients"] as? String {
            ingredients = ingredientString.components(separatedBy: "\n")
                .filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        }

        // Extract instructions with additional handling if it's a single string
        var instructions: [String] = []
        if let steps = recipeData["recipeInstructions"] as? [String] {
            instructions = steps
        } else if let steps = recipeData["recipeInstructions"] as? [[String: Any]] {
            instructions = steps.compactMap { $0["text"] as? String }
        } else if let instructionsString = recipeData["recipeInstructions"] as? String {
            instructions = instructionsString.components(separatedBy: "\n")
                .filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        }

        // Extract images
        var images: [String] = []
        if let image = recipeData["image"] as? String {
            images = [image]
        } else if let imageList = recipeData["image"] as? [String] {
            images = imageList
        }

        return (title, ingredients, instructions, images)
    }

    private func extractMicrodata(from html: String) -> (title: String, ingredients: [String], instructions: [String], images: [String])? {
        var title = ""
        var ingredients: [String] = []
        var instructions: [String] = []
        var images: [String] = []

        // Extract title (using common recipe title patterns)
        let titlePatterns = [
            "<h1[^>]*>([^<]+)</h1>",
            "<meta\\s+property=\"og:title\"\\s+content=\"([^\"]+)\"",
            "<title>([^<]+)</title>"
        ]
        for pattern in titlePatterns {
            if let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
               let match = regex.firstMatch(in: html, range: NSRange(html.startIndex..., in: html)),
               let titleRange = Range(match.range(at: 1), in: html) {
                title = String(html[titleRange])
                    .replacingOccurrences(of: "&amp;", with: "&")
                    .replacingOccurrences(of: "&#x27;", with: "'")
                    .trimmingCharacters(in: .whitespacesAndNewlines)
                break
            }
        }

        // Extract ingredients using several patterns.
        let ingredientPatterns = [
            "<li[^>]*class=\"[^\"]*ingredient[^\"]*\"[^>]*>(.*?)</li>",
            "<li[^>]*itemprop=\"recipeIngredient\"[^>]*>(.*?)</li>",
            "<div[^>]*class=\"[^\"]*ingredient[^\"]*\"[^>]*>(.*?)</div>",
            "<span[^>]*class=\"[^\"]*ingredient[^\"]*\"[^>]*>(.*?)</span>",
            "<p[^>]*class=\"[^\"]*ingredient[^\"]*\"[^>]*>(.*?)</p>",
            "<div[^>]*data-ingredient[^>]*>(.*?)</div>",
            // Extra pattern: any <li> that contains the word "ingredient" (case-insensitive)
            "(?i)<li[^>]*>([^<]*ingredient[^<]*)</li>"
        ]
        for pattern in ingredientPatterns {
            if let regex = try? NSRegularExpression(pattern: pattern, options: [.dotMatchesLineSeparators]) {
                let matches = regex.matches(in: html, range: NSRange(html.startIndex..., in: html))
                let foundIngredients = matches.compactMap { match -> String? in
                    guard let range = Range(match.range(at: 1), in: html) else { return nil }
                    return String(html[range])
                        .replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression)
                        .trimmingCharacters(in: .whitespacesAndNewlines)
                }
                if !foundIngredients.isEmpty {
                    ingredients = foundIngredients
                    break
                }
            }
        }

        // Extract instructions using several patterns.
        let instructionPatterns = [
            "<li[^>]*class=\"[^\"]*instruction[^\"]*\"[^>]*>(.*?)</li>",
            "<li[^>]*itemprop=\"recipeInstructions\"[^>]*>(.*?)</li>",
            "<div[^>]*class=\"[^\"]*instruction[^\"]*\"[^>]*>(.*?)</div>",
            "<p[^>]*class=\"[^\"]*instruction[^\"]*\"[^>]*>(.*?)</p>",
            "<div[^>]*class=\"[^\"]*step[^\"]*\"[^>]*>(.*?)</div>",
            "<ol[^>]*class=\"[^\"]*instructions[^\"]*\"[^>]*>(.*?)</ol>",
            "<div[^>]*class=\"[^\"]*recipe-method[^\"]*\"[^>]*>(.*?)</div>",
            "<div[^>]*class=\"[^\"]*preparation[^\"]*\"[^>]*>(.*?)</div>",
            "<div[^>]*class=\"[^\"]*directions[^\"]*\"[^>]*>(.*?)</div>",
            "<div[^>]*class=\"[^\"]*method-steps[^\"]*\"[^>]*>(.*?)</div>",
            "<div[^>]*class=\"[^\"]*recipe-directions[^\"]*\"[^>]*>(.*?)</div>",
            "<div[^>]*class=\"[^\"]*cooking-instructions[^\"]*\"[^>]*>(.*?)</div>",
            "<div[^>]*data-recipe-instructions[^>]*>(.*?)</div>",
            "<div[^>]*itemtype=\"http://schema.org/Recipe\"[^>]*>.*?<div[^>]*class=\"[^\"]*instructions[^\"]*\"[^>]*>(.*?)</div>"
        ]
        for pattern in instructionPatterns {
            if let regex = try? NSRegularExpression(pattern: pattern, options: [.dotMatchesLineSeparators]) {
                let matches = regex.matches(in: html, range: NSRange(html.startIndex..., in: html))
                let foundInstructions = matches.compactMap { match -> String? in
                    guard let range = Range(match.range(at: 1), in: html) else { return nil }
                    let instruction = String(html[range])
                        .replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression)
                        .replacingOccurrences(of: "&nbsp;", with: " ")
                        .replacingOccurrences(of: "&amp;", with: "&")
                        .replacingOccurrences(of: "&quot;", with: "\"")
                        .replacingOccurrences(of: "&#39;", with: "'")
                        .replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
                        .trimmingCharacters(in: .whitespacesAndNewlines)
                    return instruction.isEmpty ? nil : instruction
                }
                if !foundInstructions.isEmpty {
                    instructions = foundInstructions
                    break
                }
            }
        }

        // If we have a single block of instructions, try splitting by newline.
        if instructions.count == 1 {
            let potentialSteps = instructions[0].components(separatedBy: "\n")
                .filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
            if potentialSteps.count > 1 {
                instructions = potentialSteps
            }
        }

        // Extract images.
        let imagePatterns = [
            "<meta\\s+property=\"og:image\"\\s+content=\"([^\"]+)\"",
            "<img[^>]+class=\"[^\"]*recipe-image[^\"]*\"[^>]+src=\"([^\"]+)\"",
            "<img[^>]+src=\"([^\"]+)\"[^>]*>"
        ]
        for pattern in imagePatterns {
            if let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) {
                let matches = regex.matches(in: html, range: NSRange(html.startIndex..., in: html))
                let foundImages = matches.compactMap { match -> String? in
                    guard let range = Range(match.range(at: 1), in: html) else { return nil }
                    return String(html[range])
                }
                if !foundImages.isEmpty {
                    images = foundImages
                    break
                }
            }
        }

        return (!title.isEmpty && (!ingredients.isEmpty || !instructions.isEmpty)) ?
            (title, ingredients, instructions, images) : nil
    }

    private func downloadImage(from url: URL) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                if let data = data {
                    self.selectedImageData = data
                }
            }
        }.resume()
    }

    private func saveRecipe() {
        let recipe = RecipeEntity(context: viewContext)
        recipe.id = UUID()
        recipe.title = title
        recipe.sourceURL = sourceURL
        recipe.imageData = selectedImageData

        // Convert arrays to JSON strings
        if let ingredientsData = try? JSONEncoder().encode(ingredients.filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }) {
            recipe.ingredientsString = String(data: ingredientsData, encoding: .utf8)
        }

        if let instructionsData = try? JSONEncoder().encode(instructions.filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }) {
            recipe.instructionsString = String(data: instructionsData, encoding: .utf8)
        }

        if let tagsData = try? JSONEncoder().encode(tags.filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }) {
            recipe.tagsString = String(data: tagsData, encoding: .utf8)
        }

        // Create searchable terms
        let searchableText = [title] + ingredients + tags
        recipe.searchTerms = searchableText.joined(separator: " ")

        do {
            try viewContext.save()
            print("Recipe saved successfully.")
            dismiss()
        } catch {
            print("Error saving recipe: \(error)")
        }
    }
}

struct AddRecipeView_Previews: PreviewProvider {
    static var previews: some View {
        AddRecipeView()
            .environment(\.managedObjectContext, PersistenceController.shared.container.viewContext)
    }
}
