//
//  Mealplannerv3App.swift
//  Mealplannerv3
//
//  Created by Paul Hilton on 17/2/25.
//

import SwiftUI

@main
struct Mealplannerv3App: App {
    let persistenceController = PersistenceController.shared
    
    var body: some Scene {
        WindowGroup {
            MainMenuView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
