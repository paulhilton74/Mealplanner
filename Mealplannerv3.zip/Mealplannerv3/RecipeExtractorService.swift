import Foundation

struct Recipe {
    var title: String
    var ingredients: [String]
    var instructions: [String]
    var images: [String]
    var url: String
}

enum RecipeExtractionError: Error {
    case invalidURL
    case networkError(Error)
    case parsingError
}

class RecipeExtractorService {
    private let apiKey: String
    
    init(apiKey: String) {
        self.apiKey = apiKey
    }
    
    func extractRecipe(from urlString: String) async throws -> Recipe {
        guard let url = URL(string: urlString) else {
            throw RecipeExtractionError.invalidURL
        }
        
        return try await withCheckedThrowingContinuation { continuation in
            let session = URLSession.shared
            var request = URLRequest(url: url)
            request.setValue("Mozilla/5.0", forHTTPHeaderField: "User-Agent")
            
            session.dataTask(with: request) { data, response, error in
                if let error = error {
                    continuation.resume(throwing: RecipeExtractionError.networkError(error))
                    return
                }
                
                guard let data = data, let htmlContent = String(data: data, encoding: .utf8) else {
                    continuation.resume(throwing: RecipeExtractionError.parsingError)
                    return
                }
                
                // Extract content using regex patterns
                let title = self.extractTitle(from: htmlContent)
                let ingredients = self.extractIngredients(from: htmlContent)
                let instructions = self.extractInstructions(from: htmlContent)
                let images = self.extractImages(from: htmlContent)
                
                let recipe = Recipe(
                    title: title,
                    ingredients: ingredients, 
                    instructions: instructions, 
                    images: images,
                    url: urlString
                )
                
                continuation.resume(returning: recipe)
                
            }.resume()
        }
    }
    
    private func extractTitle(from html: String) -> String {
        let titlePatterns = [
            "<h1[^>]*>([^<]+)</h1>",
            "<meta\\s+property=\"og:title\"\\s+content=\"([^\"]+)\"",
            "<title>([^<]+)</title>"
        ]
        
        for pattern in titlePatterns {
            if let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
               let match = regex.firstMatch(in: html, options: [], range: NSRange(html.startIndex..., in: html)),
               let range = Range(match.range(at: 1), in: html) {
                return String(html[range])
                    .trimmingCharacters(in: .whitespacesAndNewlines)
                    .replacingOccurrences(of: "&amp;", with: "&")
            }
        }
        
        return "Untitled Recipe"
    }
    
    private func extractIngredients(from html: String) -> [String] {
        var ingredients: [String] = []
        let ingredientPatterns = [
            "<li[^>]*class=\"[^\"]*ingredient[^\"]*\"[^>]*>([^<]+)</li>",
            "<div[^>]*class=\"[^\"]*ingredient[^\"]*\"[^>]*>([^<]+)</div>",
            "<span[^>]*class=\"[^\"]*ingredient[^\"]*\"[^>]*>([^<]+)</span>"
        ]
        
        for pattern in ingredientPatterns {
            if let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive, .dotMatchesLineSeparators]) {
                let matches = regex.matches(in: html, options: [], range: NSRange(html.startIndex..., in: html))
                
                let foundIngredients = matches.compactMap { match -> String? in
                    guard let range = Range(match.range(at: 1), in: html) else { return nil }
                    return String(html[range])
                        .trimmingCharacters(in: .whitespacesAndNewlines)
                        .replacingOccurrences(of: "&amp;", with: "&")
                }
                
                if !foundIngredients.isEmpty {
                    ingredients = foundIngredients
                    break
                }
            }
        }
        
        return ingredients
    }
    
    private func extractInstructions(from html: String) -> [String] {
        var instructions: [String] = []
        let instructionPatterns = [
            "<li[^>]*class=\"[^\"]*instruction[^\"]*\"[^>]*>([^<]+)</li>",
            "<div[^>]*class=\"[^\"]*instruction[^\"]*\"[^>]*>([^<]+)</div>",
            "<p[^>]*class=\"[^\"]*instruction[^\"]*\"[^>]*>([^<]+)</p>"
        ]
        
        for pattern in instructionPatterns {
            if let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive, .dotMatchesLineSeparators]) {
                let matches = regex.matches(in: html, options: [], range: NSRange(html.startIndex..., in: html))
                
                let foundInstructions = matches.compactMap { match -> String? in
                    guard let range = Range(match.range(at: 1), in: html) else { return nil }
                    return String(html[range])
                        .trimmingCharacters(in: .whitespacesAndNewlines)
                        .replacingOccurrences(of: "&amp;", with: "&")
                }
                
                if !foundInstructions.isEmpty {
                    instructions = foundInstructions
                    break
                }
            }
        }
        
        return instructions
    }
    
    private func extractImages(from html: String) -> [String] {
        var images: [String] = []
        let imagePatterns = [
            "<meta\\s+property=\"og:image\"\\s+content=\"([^\"]+)\"",
            "<img[^>]+class=\"[^\"]*recipe[^\"]*\"[^>]+src=\"([^\"]+)\"",
            "<img[^>]+src=\"([^\"]+)\"[^>]*>"
        ]
        
        for pattern in imagePatterns {
            if let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) {
                let matches = regex.matches(in: html, options: [], range: NSRange(html.startIndex..., in: html))
                
                let foundImages = matches.compactMap { match -> String? in
                    guard let range = Range(match.range(at: 1), in: html) else { return nil }
                    return String(html[range])
                }
                
                if !foundImages.isEmpty {
                    images = foundImages
                    break
                }
            }
        }
        
        return images
    }
}