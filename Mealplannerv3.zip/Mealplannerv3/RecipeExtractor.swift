import Foundation

enum RecipeParsingError: Error {
    case noData
    case invalidJSON
    case invalidFormat
    case missingRequiredData
}

protocol RecipeExtractor {
    func parse(html: String, from url: URL) async -> (title: String, ingredients: [String], instructions: [String], images: [String])?
}

struct JSONLDExtractor: RecipeExtractor {
    func parse(html: String, from url: URL) async -> (title: String, ingredients: [String], instructions: [String], images: [String])? {
        do {
            let pattern = "<script[^>]*type=\"application/ld\\+json\"[^>]*>\\s*(.+?)\\s*</script>"
            guard let regex = try? NSRegularExpression(pattern: pattern, options: [.dotMatchesLineSeparators]),
                  let match = regex.firstMatch(in: html, range: NSRange(html.startIndex..., in: html)),
                  let dataRange = Range(match.range(at: 1), in: html) else {
                return nil
            }

            let jsonString = String(html[dataRange])
            guard let jsonData = jsonString.data(using: .utf8),
                  let json = try? JSONSerialization.jsonObject(with: jsonData) as? [String: Any] else {
                return nil
            }

            // Find recipe data
            let recipeData: [String: Any]
            if let type = json["@type"] as? String, type == "Recipe" {
                recipeData = json
            } else if let graph = json["@graph"] as? [[String: Any]],
                      let recipe = graph.first(where: { ($0["@type"] as? String) == "Recipe" }) {
                recipeData = recipe
            } else {
                return nil
            }

            // Extract title
            guard let title = recipeData["name"] as? String else {
                return nil
            }

            // Extract ingredients
            var ingredients: [String] = []
            if let ingredientList = recipeData["recipeIngredient"] as? [String] {
                ingredients = ingredientList
            } else if let ingredientList = recipeData["ingredients"] as? [String] {
                ingredients = ingredientList
            } else if let ingredientString = recipeData["recipeIngredient"] as? String {
                ingredients = ingredientString.components(separatedBy: "\n")
                    .filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
            }

            // Extract instructions
            var instructions: [String] = []
            if let steps = recipeData["recipeInstructions"] as? [String] {
                instructions = steps
            } else if let steps = recipeData["recipeInstructions"] as? [[String: Any]] {
                instructions = steps.compactMap { $0["text"] as? String }
            } else if let instructionsString = recipeData["recipeInstructions"] as? String {
                instructions = instructionsString.components(separatedBy: "\n")
                    .filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
            }

            // Extract images
            var images: [String] = []
            if let image = recipeData["image"] as? String {
                images = [image]
            } else if let imageList = recipeData["image"] as? [String] {
                images = imageList
            }

            return (title, ingredients, instructions, images)
        } catch {
            return nil
        }
    }
}

struct MicrodataExtractor: RecipeExtractor {
    func parse(html: String, from url: URL) async -> (title: String, ingredients: [String], instructions: [String], images: [String])? {
        // Extract title
        var title = ""
        let titlePatterns = [
            "<h1[^>]*>([^<]+)</h1>",
            "<meta\\s+property=\"og:title\"\\s+content=\"([^\"]+)\"",
            "<title>([^<]+)</title>"
        ]
        for pattern in titlePatterns {
            if let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
               let match = regex.firstMatch(in: html, range: NSRange(html.startIndex..., in: html)),
               let titleRange = Range(match.range(at: 1), in: html) {
                title = String(html[titleRange])
                    .replacingOccurrences(of: "&amp;", with: "&")
                    .replacingOccurrences(of: "&#x27;", with: "'")
                    .trimmingCharacters(in: .whitespacesAndNewlines)
                break
            }
        }

        // Extract ingredients
        var ingredients: [String] = []
        let ingredientPatterns = [
            "<li[^>]*class=\"[^\"]*ingredient[^\"]*\"[^>]*>(.*?)</li>",
            "<li[^>]*itemprop=\"recipeIngredient\"[^>]*>(.*?)</li>",
            "<div[^>]*class=\"[^\"]*ingredient[^\"]*\"[^>]*>(.*?)</div>"
        ]
        for pattern in ingredientPatterns {
            if let regex = try? NSRegularExpression(pattern: pattern, options: [.dotMatchesLineSeparators]) {
                let matches = regex.matches(in: html, range: NSRange(html.startIndex..., in: html))
                ingredients = matches.compactMap { match -> String? in
                    guard let range = Range(match.range(at: 1), in: html) else { return nil }
                    return String(html[range])
                        .replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression)
                        .trimmingCharacters(in: .whitespacesAndNewlines)
                }
                if !ingredients.isEmpty { break }
            }
        }

        // Extract instructions
        var instructions: [String] = []
        let instructionPatterns = [
            "<li[^>]*class=\"[^\"]*instruction[^\"]*\"[^>]*>(.*?)</li>",
            "<div[^>]*class=\"[^\"]*step[^\"]*\"[^>]*>(.*?)</div>",
            "<p[^>]*class=\"[^\"]*instruction[^\"]*\"[^>]*>(.*?)</p>"
        ]
        for pattern in instructionPatterns {
            if let regex = try? NSRegularExpression(pattern: pattern, options: [.dotMatchesLineSeparators]) {
                let matches = regex.matches(in: html, range: NSRange(html.startIndex..., in: html))
                instructions = matches.compactMap { match -> String? in
                    guard let range = Range(match.range(at: 1), in: html) else { return nil }
                    return String(html[range])
                        .replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression)
                        .trimmingCharacters(in: .whitespacesAndNewlines)
                }
                if !instructions.isEmpty { break }
            }
        }

        // Extract images
        var images: [String] = []
        let imagePatterns = [
            "<meta\\s+property=\"og:image\"\\s+content=\"([^\"]+)\"",
            "<img[^>]+class=\"[^\"]*recipe-image[^\"]*\"[^>]+src=\"([^\"]+)\""
        ]
        for pattern in imagePatterns {
            if let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) {
                let matches = regex.matches(in: html, range: NSRange(html.startIndex..., in: html))
                images = matches.compactMap { match -> String? in
                    guard let range = Range(match.range(at: 1), in: html) else { return nil }
                    return String(html[range])
                }
                if !images.isEmpty { break }
            }
        }

        return (!title.isEmpty && (!ingredients.isEmpty || !instructions.isEmpty)) ?
            (title, ingredients, instructions, images) : nil
    }
}