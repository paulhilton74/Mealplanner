import SwiftUI

struct RecipeDetailView: View {
    let recipe: RecipeEntity
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                if let imageData = recipe.imageData,
                   let uiImage = UIImage(data: imageData) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(maxWidth: .infinity)
                        .frame(height: uiImage.size.height > 0 ? min(300, uiImage.size.height) : 300)
                        .clipped()
                        .cornerRadius(12)
                }
                
                VStack(alignment: .leading, spacing: 8) {
                    Text(recipe.title ?? "Untitled Recipe")
                        .font(.title)
                        .bold()
                    
                    if let tagsString = recipe.tagsString,
                       let tagsData = tagsString.data(using: .utf8),
                       let tags = try? JSONDecoder().decode([String].self, from: tagsData),
                       !tags.isEmpty {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack {
                                ForEach(tags, id: \.self) { tag in
                                    Text(tag)
                                        .font(.caption)
                                        .padding(.horizontal, 8)
                                        .padding(.vertical, 4)
                                        .background(Color.blue.opacity(0.2))
                                        .cornerRadius(8)
                                }
                            }
                        }
                    }
                }
                
                if let ingredientsString = recipe.ingredientsString,
                   let ingredientsData = ingredientsString.data(using: .utf8),
                   let ingredients = try? JSONDecoder().decode([String].self, from: ingredientsData),
                   !ingredients.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Ingredients")
                            .font(.headline)
                        
                        ForEach(ingredients, id: \.self) { ingredient in
                            HStack {
                                Image(systemName: "circle.fill")
                                    .font(.system(size: 6))
                                Text(ingredient)
                            }
                        }
                    }
                }
                
                if let instructionsString = recipe.instructionsString,
                   let instructionsData = instructionsString.data(using: .utf8),
                   let instructions = try? JSONDecoder().decode([String].self, from: instructionsData),
                   !instructions.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Instructions")
                            .font(.headline)
                        
                        ForEach(Array(instructions.enumerated()), id: \.element) { index, instruction in
                            HStack(alignment: .top) {
                                Text("\(index + 1).")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                                Text(instruction)
                            }
                        }
                    }
                }
                
                if let sourceURL = recipe.sourceURL,
                   let url = URL(string: sourceURL) {
                    Link(destination: url) {
                        HStack {
                            Image(systemName: "link")
                            Text("View Original Recipe")
                        }
                    }
                }
            }
            .padding()
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button("Back") {
                    dismiss()
                }
            }
        }
    }
}
