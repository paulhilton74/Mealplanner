//
//  ContentView.swift
//  Mealplannerv3
//
//  Created by Paul Hilton on 17/2/25.
//

import SwiftUI
import CoreData

struct ContentView: View {
    @StateObject private var recipeManager = RecipeManager.shared
    @State private var showingAddRecipe = false
    @State private var searchText = ""
    @State private var selectedRecipe: RecipeEntity?
    @State private var showingRecipeDetail = false
    @State private var showingMealPlanSheet = false
    
    private let daysOfWeek = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    
    var filteredRecipes: [RecipeEntity] {
        if searchText.isEmpty {
            return recipeManager.recipes
        } else {
            return recipeManager.recipes.filter { recipe in
                let searchableText = [
                    recipe.title ?? "",
                    recipe.ingredientsString ?? "",
                    recipe.tagsString ?? ""
                ].joined(separator: " ").lowercased()
                
                return searchableText.contains(searchText.lowercased())
            }
        }
    }
    
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Weekly Meal Plan")) {
                    ForEach(daysOfWeek, id: \.self) { day in
                        HStack {
                            Text(day)
                                .fontWeight(.medium)
                            Spacer()
                            if let recipe = recipeManager.weeklyPlan[day] {
                                Text(recipe.title ?? "Untitled Recipe")
                                    .foregroundColor(.blue)
                                
                                Button(action: {
                                    recipeManager.removeRecipe(fromDay: day)
                                }) {
                                    Image(systemName: "xmark.circle.fill")
                                        .foregroundColor(.red)
                                }
                            } else {
                                Button("Add") {
                                    showingMealPlanSheet = true
                                }
                                .sheet(isPresented: $showingMealPlanSheet) {
                                    MealPlanView(selectedDay: day)
                                }
                            }
                        }
                    }
                }
                
                Section(header: Text("All Recipes")) {
                    ForEach(filteredRecipes) { recipe in
                        RecipeRowView(recipe: recipe)
                            .contentShape(Rectangle())
                            .onTapGesture {
                                selectedRecipe = recipe
                                showingRecipeDetail = true
                            }
                    }
                    .onDelete { indexSet in
                        indexSet.forEach { index in
                            let recipe = filteredRecipes[index]
                            recipeManager.deleteRecipe(recipe)
                        }
                    }
                }
            }
            .searchable(text: $searchText, prompt: "Search recipes")
            .navigationTitle("Meal Planner")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { showingAddRecipe = true }) {
                        Image(systemName: "plus")
                    }
                }
            }
            .sheet(isPresented: $showingAddRecipe) {
                AddRecipeView()
            }
            .sheet(isPresented: $showingRecipeDetail) {
                if let recipe = selectedRecipe {
                    RecipeDetailView(recipe: recipe)
                }
            }
        }
    }
}

struct RecipeRowView: View {
    let recipe: RecipeEntity
    
    var body: some View {
        HStack(spacing: 12) {
            if let imageData = recipe.imageData,
               let uiImage = UIImage(data: imageData) {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 60, height: 60)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
            } else {
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color.gray.opacity(0.2))
                    .frame(width: 60, height: 60)
                    .overlay(
                        Image(systemName: "photo")
                            .foregroundColor(.gray)
                    )
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text(recipe.title ?? "Untitled Recipe")
                    .font(.headline)
                
                if let tagsString = recipe.tagsString,
                   let tags = try? JSONDecoder().decode([String].self, from: tagsString.data(using: .utf8) ?? Data()),
                   !tags.isEmpty {
                    Text(tags.joined(separator: ", "))
                        .font(.caption)
                        .foregroundColor(.gray)
                }
            }
        }
        .padding(.vertical, 4)
    }
}

struct MealPlanView: View {
    let selectedDay: String
    @StateObject private var recipeManager = RecipeManager.shared
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            List(recipeManager.recipes) { recipe in
                NavigationLink(destination: RecipeDetailView(recipe: recipe)) {
                    RecipeRowView(recipe: recipe)
                        .task {
                            // Preload image data asynchronously
                            if let imageData = recipe.imageData {
                                _ = UIImage(data: imageData)
                            }
                        }
                }
            }
            .listStyle(PlainListStyle())
            .refreshable {
                recipeManager.loadRecipes()
            }
            .navigationTitle("Select Recipe for \(selectedDay)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
        }
    }
}

#Preview {
    ContentView()
        .environment(\.managedObjectContext, PersistenceController.shared.container.viewContext)
}
