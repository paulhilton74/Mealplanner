import Foundation

enum APIConstants {
    static let openAIKey = "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"
}