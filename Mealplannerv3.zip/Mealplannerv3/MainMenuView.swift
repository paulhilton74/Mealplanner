import SwiftUI

struct MainMenuView: View {
    @State private var showingAddRecipe = false
    @State private var showingCreateMealPlan = false
    @State private var showingShoppingBasket = false
    @State private var showingWeeklyMealPlan = false
    @State private var showingRecipeList = false
    
    var body: some View {
        NavigationView {
            ZStack {
                Color(.systemGroupedBackground)
                    .ignoresSafeArea()
                
                VStack(spacing: 20) {
                    Text("Meal Planner")
                        .font(.largeTitle)
                        .bold()
                        .padding(.top, 40)
                    
                    Spacer()
                    
                    VStack(spacing: 16) {
                        MenuButton(title: "Add Recipe", icon: "plus.circle.fill") {
                            showingAddRecipe = true
                        }
                        
                        MenuButton(title: "Create Meal Plan", icon: "calendar.badge.plus") {
                            showingCreateMealPlan = true
                        }
                        
                        MenuButton(title: "Shopping Basket", icon: "cart.fill") {
                            showingShoppingBasket = true
                        }
                        
                        MenuButton(title: "View Weekly Plan", icon: "calendar") {
                            showingWeeklyMealPlan = true
                        }
                        
                        MenuButton(title: "Recipe Library", icon: "book.fill") {
                            showingRecipeList = true
                        }
                    }
                    .padding(.horizontal)
                    
                    Spacer()
                }
            }
            .sheet(isPresented: $showingAddRecipe) {
                AddRecipeView()
            }
            .sheet(isPresented: $showingCreateMealPlan) {
                CreateMealPlanView()
            }
            .sheet(isPresented: $showingShoppingBasket) {
                ShoppingBasketView()
            }
            .sheet(isPresented: $showingWeeklyMealPlan) {
                WeeklyMealPlanView()
            }
            .fullScreenCover(isPresented: $showingRecipeList) {
                ContentView()
            }
        }
    }
}

struct MenuButton: View {
    let title: String
    let icon: String
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 15) {
                Image(systemName: icon)
                    .font(.title2)
                    .foregroundColor(.white)
                    .frame(width: 30)
                
                Text(title)
                    .font(.title3)
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .font(.title3)
                    .foregroundColor(.white.opacity(0.7))
            }
            .padding()
            .background(Color.blue)
            .cornerRadius(12)
        }
    }
}

#Preview {
    MainMenuView()
}
