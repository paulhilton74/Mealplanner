import SwiftUI

struct DaySelectionView: View {
    let weekDays: [String]
    let selectedDay: Int
    let onDaySelected: (Int) -> Void
    
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 0) {
                ForEach(0..<7) { index in
                    DayCell(weekDay: weekDays[index],
                           date: getDate(for: index),
                           isSelected: selectedDay == index,
                           onTap: { onDaySelected(index) })
                }
            }
            .padding(.horizontal)
        }
        .padding(.vertical, 8)
        .background(Color(.systemBackground))
    }
    
    private func getDate(for dayOffset: Int) -> Date {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())
        let weekday = calendar.component(.weekday, from: today) - 1
        let daysToAdd = dayOffset - weekday
        return calendar.date(byAdding: .day, value: daysToAdd, to: today) ?? today
    }
}

struct DayCell: View {
    let weekDay: String
    let date: Date
    let isSelected: Bool
    let onTap: () -> Void
    
    var body: some View {
        VStack {
            Text(weekDay)
                .font(.subheadline)
                .foregroundColor(isSelected ? .white : .primary)
            
            Text("\(Calendar.current.component(.day, from: date))")
                .font(.caption)
                .foregroundColor(isSelected ? .white : .gray)
        }
        .frame(width: 80)
        .padding(.vertical, 8)
        .background(isSelected ? Color.blue : Color.clear)
        .clipShape(RoundedRectangle(cornerRadius: 10))
        .onTapGesture {
            withAnimation {
                onTap()
            }
        }
    }
}

struct RecipeListView: View {
    let recipe: RecipeEntity?
    let weekDay: String
    let onAddRecipe: () -> Void
    
    var body: some View {
        if let recipe = recipe {
            NavigationLink {
                RecipeDetailView(recipe: recipe)
            } label: {
                RecipeRow(recipe: recipe)
            }
        } else {
            Button(action: onAddRecipe) {
                HStack {
                    Image(systemName: "plus.circle.fill")
                        .foregroundColor(.blue)
                    Text("Add Recipe")
                        .foregroundColor(.blue)
                }
            }
        }
    }
}

struct RecipeRow: View {
    let recipe: RecipeEntity
    
    var body: some View {
        HStack {
            if let imageData = recipe.imageData,
               let uiImage = UIImage(data: imageData) {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 60, height: 60)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
            } else {
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color.gray.opacity(0.2))
                    .frame(width: 60, height: 60)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text(recipe.title ?? "Untitled Recipe")
                    .font(.headline)
                
                if let ingredientsString = recipe.ingredientsString,
                   let ingredientsData = ingredientsString.data(using: .utf8),
                   let ingredients = try? JSONDecoder().decode([String].self, from: ingredientsData) {
                    Text("\(ingredients.count) ingredients")
                        .font(.caption)
                        .foregroundColor(.gray)
                }
            }
        }
        .padding(.vertical, 4)
    }
}

struct WeeklyMealPlanView: View {
    @StateObject private var recipeManager = RecipeManager.shared
    @Environment(\.dismiss) private var dismiss
    @State private var selectedDay: Int = Calendar.current.component(.weekday, from: Date()) - 1
    @State private var showingRecipeSelection = false
    
    let weekDays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                DaySelectionView(weekDays: weekDays,
                                selectedDay: selectedDay,
                                onDaySelected: { selectedDay = $0 })
                
                List {
                    RecipeListView(
                        recipe: recipeManager.weeklyPlan[weekDays[selectedDay]],
                        weekDay: weekDays[selectedDay],
                        onAddRecipe: {
                            recipeManager.weeklyPlan[weekDays[selectedDay]] = nil
                            showingRecipeSelection = true
                        }
                    )
                }
                .listStyle(PlainListStyle())
            }
            .navigationTitle("Weekly Meal Plan")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Menu") {
                        dismiss()
                    }
                }
            }
            .sheet(isPresented: $showingRecipeSelection) {
                RecipeSelectionView(selectedRecipe: Binding(
                    get: { recipeManager.weeklyPlan[weekDays[selectedDay]] },
                    set: { newValue in
                        if let newValue = newValue {
                            recipeManager.assignRecipe(newValue, toDay: weekDays[selectedDay])
                        }
                    }
                ))
            }
        }
    }
}
    
#Preview {
    WeeklyMealPlanView()
        .environment(\.managedObjectContext, PersistenceController.shared.container.viewContext)
}
