import SwiftUI

struct CreateMealPlanView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var recipeManager = RecipeManager.shared
    
    @State private var selectedDay: Int?
    @State private var showingRecipeSelection = false
    @State private var weeklyPlan: [Int: RecipeEntity] = [:]
    @State private var showingSaveConfirmation = false
    
    let daysOfWeek = [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday"
    ]
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                List {
                    ForEach(Array(daysOfWeek.enumerated()), id: \.offset) { index, day in
                        HStack {
                            Text(day)
                                .font(.headline)
                            
                            Spacer()
                            
                            if let recipe = weeklyPlan[index] {
                                Text(recipe.title ?? "")
                                    .foregroundColor(.blue)
                            }
                            
                            Button(action: {
                                selectedDay = index
                                showingRecipeSelection = true
                            }) {
                                Text(weeklyPlan[index] == nil ? "Select" : "Change")
                                    .foregroundColor(.blue)
                            }
                        }
                        .padding(.vertical, 8)
                    }
                }
            }
            .navigationTitle("Create Meal Plan")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Menu") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        recipeManager.saveWeeklyPlan(weeklyPlan)
                        showingSaveConfirmation = true
                    }
                    .disabled(weeklyPlan.isEmpty)
                }
            }
            .sheet(isPresented: $showingRecipeSelection) {
                RecipeSelectionView(selectedRecipe: Binding(
                    get: { weeklyPlan[selectedDay ?? 0] },
                    set: { newValue in
                        if let newValue = newValue, let selectedDay = selectedDay {
                            weeklyPlan[selectedDay] = newValue
                        }
                    }
                ))
            }
            .alert("Meal Plan Saved", isPresented: $showingSaveConfirmation) {
                Button("OK") {
                    dismiss()
                }
            } message: {
                Text("Your weekly meal plan has been saved successfully.")
            }
            .onAppear {
                weeklyPlan = recipeManager.loadCurrentWeekPlan()
            }
        }
    }
}

struct RecipeSelectionView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var recipeManager = RecipeManager.shared
    @State private var searchText = ""
    @Binding var selectedRecipe: RecipeEntity?
    
    var filteredRecipes: [RecipeEntity] {
        if searchText.isEmpty {
            return recipeManager.recipes
        }
        
        let searchTerms = searchText.lowercased().split(separator: " ")
        return recipeManager.recipes.filter { recipe in
            let searchableText = (recipe.searchTerms ?? "").lowercased()
            return searchTerms.allSatisfy { searchableText.contains($0) }
        }
    }
    
    var body: some View {
        NavigationView {
            VStack {
                // Search Bar
                SearchBar(text: $searchText)
                    .padding()
                
                // Recipe List
                List(filteredRecipes) { recipe in
                    Button(action: {
                        selectedRecipe = recipe
                        dismiss()
                    }) {
                        RecipeRowView(recipe: recipe)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                }
            }
            .navigationTitle("Select Recipe")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
        }
    }
}

struct SearchBar: View {
    @Binding var text: String
    
    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.gray)
            
            TextField("Search recipes...", text: $text)
                .textFieldStyle(RoundedBorderTextFieldStyle())
            
            if !text.isEmpty {
                Button(action: { text = "" }) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.gray)
                }
            }
        }
    }
}

#Preview {
    CreateMealPlanView()
}
