import SwiftUI
import CoreData

// First define EmptyStateView before ShoppingBasketView
struct EmptyStateView: View {
    @ObservedObject var basketManager: ShoppingBasketManager
    @State private var showingSavedLists = false
    
    var body: some View {
        VStack(spacing: 20) {
            Text("No items in shopping list")
                .font(.headline)
                .foregroundColor(.gray)
            
            Button(action: {
                basketManager.generateShoppingList()
            }) {
                HStack {
                    Image(systemName: "list.bullet.rectangle")
                    Text("Generate Shopping List")
                }
                .font(.headline)
                .foregroundColor(.white)
                .padding()
                .background(Color.blue)
                .cornerRadius(10)
            }
            
            Button(action: {
                showingSavedLists = true
            }) {
                HStack {
                    Image(systemName: "folder")
                    Text("Open Saved List")
                }
                .font(.headline)
                .foregroundColor(.blue)
            }
        }
        .sheet(isPresented: $showingSavedLists) {
            SavedListsView(basketManager: basketManager)
        }
    }
}

enum IngredientCategory: String {
    case dairy
    case pantry
    case other
}

class ShoppingBasketManager: ObservableObject {
    @Published var currentList: ShoppingList?
    @Published var items: [ShoppingItem] = []
    @Published var isGenerating = false
    
    private let persistence = PersistenceController.shared
    private let recipeManager = RecipeManager.shared
    
    func generateShoppingList() {
        isGenerating = true
        let context = persistence.container.viewContext
        
        // Delete existing list if present
        if let currentList = currentList {
            context.delete(currentList)
            try? context.save()
        }
        
        // Create new list
        let list = ShoppingList(context: context)
        list.id = UUID()
        list.name = "Shopping List"
        list.createdAt = Date()
        
        var newItems: [ShoppingItem] = []
        var ingredientCounts: [String: (quantity: Int, category: IngredientCategory)] = [:]
        
        let weeklyPlan = recipeManager.loadCurrentWeekPlan()
        
        // Fix the recipe handling
        for case let recipe? in weeklyPlan.values {
            if let ingredientsString = recipe.ingredientsString,
               let ingredientsData = ingredientsString.data(using: String.Encoding.utf8),
               let ingredients = try? JSONDecoder().decode([String].self, from: ingredientsData) {
                for ingredient in ingredients {
                    let components = parseIngredient(ingredient)
                    let name = components.name.trimmingCharacters(in: CharacterSet.whitespaces)
                    
                    if let existing = ingredientCounts[name] {
                        ingredientCounts[name] = (existing.quantity + components.quantity, existing.category)
                    } else {
                        ingredientCounts[name] = (components.quantity, categorizeIngredient(name))
                    }
                }
            }
        }
        
        for (name, details) in ingredientCounts {
            let item = ShoppingItem(context: context)
            item.id = UUID()
            item.name = name
            item.quantity = Int32(details.quantity)
            item.category = details.category.rawValue
            item.isChecked = false
            item.list = list
            newItems.append(item)
        }
        
        do {
            try context.save()
            currentList = list
            items = newItems
        } catch {
            print("Error generating list: \(error)")
            context.rollback()
        }
        
        isGenerating = false
    }
    
    func deleteCurrentList() {
        let context = persistence.container.viewContext
        
        if let currentList = currentList {
            context.delete(currentList)
            try? context.save()
            
            self.currentList = nil
            self.items = []
        }
    }
    
    func removeItem(_ item: ShoppingItem) {
        let context = persistence.container.viewContext
        
        if let index = items.firstIndex(of: item) {
            items.remove(at: index)
            context.delete(item)
            try? context.save()
        }
    }
    
    func updateItemQuantity(_ item: ShoppingItem, quantity: Int) {
        let context = persistence.container.viewContext
        
        if quantity <= 0 {
            removeItem(item)
        } else {
            item.quantity = Int32(quantity)
            try? context.save()
        }
    }
    
    private func parseIngredient(_ ingredient: String) -> (quantity: Int, name: String) {
        let pattern = "^(\\d+)?\\s*(.+)$"
        if let regex = try? NSRegularExpression(pattern: pattern),
           let match = regex.firstMatch(in: ingredient, range: NSRange(ingredient.startIndex..., in: ingredient)) {
            let quantityRange = Range(match.range(at: 1), in: ingredient)
            let nameRange = Range(match.range(at: 2), in: ingredient)
            
            let quantity = quantityRange.flatMap { Int(String(ingredient[$0])) } ?? 1
            let name = nameRange.map { String(ingredient[$0]) } ?? ingredient
            
            return (quantity, name)
        }
        
        return (1, ingredient)
    }
    
    private func categorizeIngredient(_ name: String) -> IngredientCategory {
        let lowercaseName = name.lowercased()
        
        if lowercaseName.contains("milk") || lowercaseName.contains("cheese") ||
            lowercaseName.contains("yogurt") || lowercaseName.contains("egg") ||
            lowercaseName.contains("butter") {
            return .dairy
        }
        
        if lowercaseName.contains("flour") || lowercaseName.contains("sugar") ||
            lowercaseName.contains("oil") || lowercaseName.contains("pasta") ||
            lowercaseName.contains("rice") {
            return .pantry
        }
        
        return .other
    }
}

struct ShoppingBasketView: View {
    @StateObject private var basketManager = ShoppingBasketManager()
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            VStack {
                if let currentList = basketManager.currentList {
                    ShoppingListView(list: currentList, basketManager: basketManager)
                } else {
                    EmptyStateView(basketManager: basketManager)
                }
            }
            .navigationTitle("Shopping List")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Menu") {
                        dismiss()
                    }
                }
                
                if basketManager.currentList != nil {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Menu {
                            Button(action: {
                                basketManager.generateShoppingList()
                            }) {
                                Label("Generate New List", systemImage: "arrow.clockwise")
                            }
                            
                            Button(role: .destructive, action: {
                                basketManager.deleteCurrentList()
                            }) {
                                Label("Delete List", systemImage: "trash")
                            }
                        } label: {
                            Image(systemName: "ellipsis.circle")
                        }
                    }
                }
            }
            .overlay {
                if basketManager.isGenerating {
                    Color.black.opacity(0.3)
                        .ignoresSafeArea()
                        .overlay(
                            ProgressView("Generating list...")
                                .padding()
                                .background(Color.white)
                                .cornerRadius(10)
                        )
                }
            }
        }
    }
}